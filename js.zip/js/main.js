$(document).ready(function() {
   // Stuff to do as soon as the DOM is ready



});

var selected=$('#head_tile').data('page-info');
$('#'+selected).addClass('current-menu-item');
